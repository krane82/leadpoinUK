<h1>Hi there :-)</h1>
<!--<pre>-->
<?php
//print_r($result);
//?>
<!--</pre>-->