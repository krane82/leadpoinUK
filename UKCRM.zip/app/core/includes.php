<?php
// main db instance
require_once( _MAIN_DOC_ROOT_ .'/app/classes/class.db.php');
//$database = DB::getInstance();
//require_once( _MAIN_DOC_ROOT_.'/app/classes/class_user.php' );
//$user = UserClass::getInstance();
//require_once( _MAIN_DOC_ROOT_.'/app/classes/class_server.php' );
//$api = MyAPI::getInstance();
//require_once( _MAIN_DOC_ROOT_.'/app/classes/class_admin.php' );
//$adminc = AdminClass::getInstance();
//require_once( _MAIN_DOC_ROOT_.'/app/classes/class_client.php' );
//$client = ClientClass::getInstance();
?>